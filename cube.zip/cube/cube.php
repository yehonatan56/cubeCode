<?php

/**
 * @package Just a simple plugin
 * @version 1.0.0
 */
/*
Plugin Name: cube
Plugin URI:
Description: create 3d cube
Author: Daniel Kalaora and yehonatan refael cohen
Version: 1.0.0
Author URI: https://chidoripunk.github.io/
*/


// We need some CSS to position the paragraph.
function custom_animation_css($args)
{	// shortcode activation is aas follows (written within the qoutes): "[show-custom-animation width=200 height=200 some_other_attribute=value]"
	$width = !empty($args["width"]) ? $args["width"] : 200; // check if empty then value is set to 200 otherwise uses the value given
	$aniamtionSpeed = !empty($args["animation_speed"]) ? $args["animation_speed"] : "20s";
	$aniamtionRotateX = !empty($args["animation_rotatex"]) ? $args["animation_rotatex"] : 0;
	$aniamtionRotateY = !empty($args["animation_rotatey"]) ? $args["animation_rotatey"] : 0;
	$aniamtionRotateZ = !empty($args["animation_rotatez"]) ? $args["animation_rotatez"] : 0;
	$cubeBackgroundColor = !empty($args["cube_background_color"]) ? $args["cube_background_color"] : "#000";
	$cubeFrameColor = !empty($args["cube_frame_color"]) ? $args["cube_frame_color"] : "#000";
	$cubeBorderSize = !empty($args["cube_border_size"]) ? $args["cube_border_size"] : 0;
	$cubeBorderColor = !empty($args["cube_border_color"]) ? $args["cube_border_color"] : "#fff";
	$cubeFaceTopImageUrl = !empty($args["cube_face_top_image_url"]) ? $args["cube_face_top_image_url"] : "";
	$cubeFaceRightImageUrl = !empty($args["cube_face_right_image_url"]) ? $args["cube_face_right_image_url"] : "";
	$cubeFaceBottomImageUrl = !empty($args["cube_face_bottom_image_url"]) ? $args["cube_face_bottom_image_url"] : "";
	$cubeFaceLeftImageUrl = !empty($args["cube_face_left_image_url"]) ? $args["cube_face_left_image_url"] : "";
	$cubeFaceBackImageUrl = !empty($args["cube_face_back_image_url"]) ? $args["cube_face_back_image_url"] : "";
	$cubeFaceFrontImageUrl = !empty($args["cube_face_front_image_url"]) ? $args["cube_face_front_image_url"] : "";

	$aniamtionTransform = "";
	if ($aniamtionRotateX != 0) {
	 	$aniamtionTransform .= 'rotateX(' .$aniamtionRotateX . 'deg)';
	}
	if ($aniamtionRotateY != 0) {
	 	$aniamtionTransform .= 'rotateY(' .$aniamtionRotateY . 'deg)';
	}
	if ($aniamtionRotateZ != 0) {
	 	$aniamtionTransform .= 'rotateZ(' .$aniamtionRotateZ . 'deg)';
	}
	echo "
	<style type='text/css'>
		.cube{
			position: relative;
			width: " . $width . "px;
			height: " . $width . "px;
			transform-style: preserve-3d;
			animation: rotate " . $aniamtionSpeed . "s infinite linear;
		}
		
		@keyframes rotate {              
			to {
				transform: " . $aniamtionTransform . ";
				}
		}
		.cube-face { position: absolute; width: " . $width . "px; height: " . $width . "px; background-color: " . $cubeBackgroundColor . "; background-size: coite; background-repeat: no-repeat; background-position: center; border: " . $cubeBorderSize . "px solid " . $cubeBorderColor . "; }
		.top { background-image: url(\"" . $cubeFaceTopImageUrl . "\"); transform: rotateX(90deg) translateZ(".($width/2)."px); }
		.right { background-image: url(\"" . $cubeFaceRightImageUrl . "\"); transform: translateZ(-".($width/2)."px) translateY(2px) rotateY(180deg); }
		.bottom { background-image: url(\"" . $cubeFaceBottomImageUrl . "\"); transform: rotateX(90deg) translateZ(-".($width/2)."px) ; }
		.left { background-image: url(\"" . $cubeFaceLeftImageUrl . "\"); transform: translateZ(".($width/2)."px) translateY(-2px); }
		.back { background-image: url(\"" . $cubeFaceBackImageUrl . "\"); transform: rotateY(90deg) translateZ(".($width/2)."px);  }
		.front { background-image: url(\"" . $cubeFaceFrontImageUrl . "\"); transform:  rotateY(90deg)translateZ(-".($width/2)."px) rotateY(180deg) ; }
		.wireframe { position: relative; }
		.wireframe:after { content: 'wireframe'; color: #000; position: absolute; left: 15px; }
		.wireframe:checked ~ .cube > .cube-face { background: none; border: 3px solid " . $cubeFrameColor . "; }
	</style>
	";
}


function custom_animation($atts)
{

	add_action('wp_head', function() use ( $atts ) {
		custom_animation_css( $atts ); }); // fire the action of the style tag

	$debugFrame = ""; // empty string if debug mode is false

	if (!empty($args["debug_mode"]) && $args["debug_mode"]) {
		$debugFrame = "<input type=\"checkbox\" class=\"wireframe\">";
	}

	// from here on it's the HTML structure
	$html = $debugFrame;
	$html .= "<div class=\"cube\">";
	$html .= 	"<div class=\"cube-face top\"></div>";
	$html .= 	"<div class=\"cube-face right\"></div>";
	$html .= 	"<div class=\"cube-face left\"></div> ";
	$html .= 	"<div class=\"cube-face bottom\"></div>";
	$html .= 	"<div class=\"cube-face front\"></div>";
	$html .= 	"<div class=\"cube-face back\"></div>";
	$html .= "</div>";
	return $html;
}

add_shortcode("show-custom-animation", "custom_animation"); // fire the plugin into action
